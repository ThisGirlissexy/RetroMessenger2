echo Checking that the necessary tools are available...
check_command gcc
check_command g++
check_command make
check_command svn
